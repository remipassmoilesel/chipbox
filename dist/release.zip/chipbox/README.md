# Chipbox

## Presentation

Minimal network system inspired by PirateBox project: https://piratebox.cc/

This project is a lighter alternative, with less tools and less configuration. 
 
Enjoy, it's a free software !

## Features

* Chat, thanks to adamoutler/MinimalChatExtreme
* File sharing, thanks to muchweb/simple-php-upload


