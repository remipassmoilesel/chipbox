<?php

// This is a local configuration file.
// Please limit your configuration to settings below.

$settings['debug'] = false;
$settings['title'] = "Chipbox upload";
$settings['description'] = "Upload files and share them !";
$settings['allow_deletion'] = true;


