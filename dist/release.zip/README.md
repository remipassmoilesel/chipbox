# Minibox

Minimal network system inspired by PirateBox Project.

Just simplest with less configuration and less tools. 

